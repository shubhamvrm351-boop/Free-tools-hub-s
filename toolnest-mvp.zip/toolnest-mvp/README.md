# ToolNest MVP

A mobile-first, browser-based online tools MVP.

## Included working tools
- ATS-style CV builder with factual user-entered content and PDF export
- Merge PDF
- Extract selected PDF pages
- Rotate PDF pages
- PDF pages to JPG
- Image resize / compression / format conversion
- Word and character counter
- Text case converter
- QR code generator
- Date difference calculator

## Run locally
Open `index.html` in a modern browser with an internet connection. Third-party libraries are loaded from CDNs.

## Deploy free
1. Create a GitHub repository and upload `index.html`.
2. In Cloudflare dashboard, open Workers & Pages.
3. Create a Pages project and connect the GitHub repository.
4. Use framework preset `None`, build command `exit 0`, output directory `/`.
5. Deploy.

## Important limitations
- This MVP does not include PDF-to-Word, Word-to-PDF, true lossless PDF compression, login, cloud storage, payment processing, AdSense or admin analytics.
- PDF rendering, PDF operations and QR generation load third-party libraries from CDNs; internet access is needed.
- PDF-to-JPG downloads one image per page and may trigger multiple browser downloads.
- Browser capabilities vary. Test outputs before using them.
- No file uploads are sent to a ToolNest server by the included tools.
- This is a starter MVP, not a security-audited production SaaS. Add a privacy policy, terms, support contact, robust testing and payment verification before accepting payments.
